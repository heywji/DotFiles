# [Bug Report] Severe TX Throughput Degradation in Windows 11 Virtio-net (10G P2P Environment)

## 1. Issue Description
In a strict Point-to-Point (P2P) 10G network environment, the Windows 11 guest using the `virtio-net` driver experiences a catastrophic drop in Transmit (TX) throughput. 

While the Receive (RX) throughput operates normally at wire-speed (**~9.4 Gbps**), the TX throughput drops to **~123 Mbps** (approx. 1.3% of the expected capacity). This massive asymmetry indicates a severe regression or bottleneck in the Win11 guest's TX path or the virtio-net driver implementation.

## 2. Environment Details

### 2.1 Software Versions
*   **Host OS:** RHEL 10.1 GA (RHEL-10.1-20251021.0)
*   **Kernel:** `kernel-6.12.0-124.8.1.el10_1.x86_64`
*   **QEMU:** `qemu-kvm-core-10.0.0-14.el10_1.x86_64`
*   **SeaBIOS:** `seabios-bin-1.16.3-7.el10.noarch`
*   **OVMF:** `edk2-ovmf-20250523-2.el10.noarch`
*   **SWTPM:** `swtpm-0.9.0-5.el10.x86_64`
*   **Guest OS:** Windows 11 x86_64
*   **Virtio-win Driver:** `virtio-win-1.9.51-0.el10_1.iso`

### 2.2 Hardware & Topology
*   **Host A (System Under Test):** `dell-per760-33`
    *   **NIC:** Intel 82599ES 10-Gigabit SFI/SFP+ (`ens8f1`)
*   **Host B (Traffic Generator):** `dell-per760-35`
    *   **NIC:** Intel 82599ES 10-Gigabit SFI/SFP+ (`ens7f1`)
*   **Connection:** Direct fiber connection (Back-to-Back P2P). **No external switches involved.**

## 3. Reproduction Steps

To ensure absolute isolation and prevent Host NetworkManager from interfering (which could cause the TAP device to fallback to a public bridge and acquire a DHCP IP), follow these exact steps:

### Step 3.1: Prepare Host B (Traffic Generator)
```bash
# On dell-per760-35
ip addr add 192.168.100.35/24 dev ens7f1
ip link set ens7f1 up
```

### Step 3.2: Prepare Host A (System Under Test)
Prevent NetworkManager from hijacking the test interfaces and create a dedicated private bridge:
```bash
# On dell-per760-33
nmcli device set ens8f1 managed no
ip link add name br_test type bridge
nmcli device set br_test managed no
ip link set ens8f1 master br_test
ip link set ens8f1 up
ip link set br_test up

root@dell-per760-33:/home/wji# vim nic.sh
-device '{"driver": "virtio-net-pci", "mac": "9a:99:5c:4c:9a:f0", "id": "idZFb0YY", "netdev": "iddLnwdr", "bus": "pcie-root-port-3", "addr": "0x0"}' \
-netdev  '{"id": "iddLnwdr", "type": "tap", "vhost": true, "script": "/etc/qemu-ifup33"}' \
root@dell-per760-33:/home/wji# cp -ra /etc/qemu-ifup  /etc/qemu-ifup33
root@dell-per760-33:/home/wji# vim /etc/qemu-ifup33
#!/bin/sh
switch=br_test
/usr/sbin/ip link set $1 up
/usr/sbin/ip link set dev $1 master ${switch}
/usr/sbin/ip link set ${switch} type bridge forward_delay 0
/usr/sbin/ip link set ${switch} type bridge stp_state 0
root@dell-per760-33:/home/wji# bash nic.sh 
qemu-kvm: -device {"driver": "rtl8139", "mac": "9a:37:37:37:37:6e", "id": "idfDUioP", "netdev": "idsT37xy", "bus": "pcie-pci-bridge-0", "addr": "0x1"}: warning: 'rtl8139' is deprecated, please use a different Network Interface Card
root@dell-per760-33:~# brctl show
bridge name     bridge id               STP enabled     interfaces
br_test         8000.1aff152c3092       no              ens8f1
                                                        tap0
switch          8000.c4cbe1da6808       no              eno8303
                                                        tap1
virbr0          8000.5254002175fb       yes
root@dell-per760-33:~# 
```

### Step 3.3: Configure Win11 Guest Network
1. Inside Win11, **disable the management NIC** (if any) to force all traffic through virtio-net.
2. Set a static IP for the virtio-net adapter:
    *   IP: `192.168.100.33`
    *   Mask: `255.255.255.0`
    *   **Default Gateway: (Leave Empty)**
    *   **DNS: (Leave Empty)**
3. Disable Windows Firewall completely:
```cmd
# On the Windows 11
C:\Users\Administrator>netsh advfirewall set allprofiles state off
C:\Users\Administrator>d:\netserver-2.6.0.exe
```

## 4. Test Results & Evidence

Execute the following commands from **Host B (`dell-per760-35`)** using `netperf-2.7.1`:

### Test 1: RX Throughput (Normal)
Testing traffic flowing from Host B -> Win11 Guest.
**Command:**
```bash
numactl --cpunodebind=1 --membind=1 python3 /tmp/netperf_agent.py 1 /tmp/netperf-2.7.1/src/netperf -D 1 -H 192.168.100.33 -l 15.0 -C -c -t TCP_STREAM -- -m 1024
```
**Result (Snippet):**
```text
Recv   Send    Send                          Utilization       Service Demand
Socket Socket  Message  Elapsed              Send     Recv     Send    Recv
Size   Size    Size     Time     Throughput  local    remote   local   remote
bytes  bytes   bytes    secs.    10^6bits/s  % S      % ?      us/KB   us/KB

 65536  16384   1024    15.00      9409.75   0.64     42.32    0.356   -0.737
```
**Observation:** RX throughput is **~9.4 Gbps** (Wire-speed expected for 10G). Virtio-net RX path is perfectly healthy.

### Test 2: TX Throughput (Severe Degradation)
Testing traffic flowing from Win11 Guest -> Host B (Using `TCP_MAERTS`).
**Command:**
```bash
numactl --cpunodebind=1 --membind=1 python3 /tmp/netperf_agent.py 1 /tmp/netperf-2.7.1/src/netperf -D 1 -H 192.168.100.33 -l 15.0 -C -c -t TCP_MAERTS -- -m 1024
```
**Result (Snippet):**
```text
Recv   Send    Send                          Utilization       Service Demand
Socket Socket  Message  Elapsed              Recv     Send     Recv    Send
Size   Size    Size     Time     Throughput  local    remote   local   remote
bytes  bytes   bytes    secs.    10^6bits/s  % S      % ?      us/KB   us/KB

 65536  16384  65536    15.00       123.12   0.02     3.30     0.977   -4.392
```
**Observation:** TX throughput is severely degraded to **~123 Mbps**. 

## 5. Conclusion
In an isolated 10G P2P environment, the Windows 11 guest equipped with `virtio-win-1.9.51-0.el10_1.iso` fails to transmit packets at expected rates, causing a massive performance bottleneck (TX throughput drops to ~1.3% of RX capability). This explicitly points to an issue in the Virtio-net TX handling path within the Windows guest or the host's vhost-net backend interaction with this specific driver version.