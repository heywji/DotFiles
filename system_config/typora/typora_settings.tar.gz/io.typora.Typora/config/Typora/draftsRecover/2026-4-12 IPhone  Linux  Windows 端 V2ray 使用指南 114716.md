# **IPhone / Linux / Windows 端 V2ray 使用指南** 

Refer: [https://www.jiwenkang.com/v2ray/v2ray%20%E6%90%AD%E5%BB%BA%E6%95%99%E7%A8%8B.md](https://www.jiwenkang.com/v2ray/v2ray 搭建教程.md) 

 

## **一、iPhone 端操作指南（Shadowrocket）** 【 安卓端同理】

### **1）安装客户端** 

在 iPhone 上打开 **App Store**，搜索并安装 **Shadowrocket**。你文档里把它作为 iOS 客户端列出来，Apple 的应用页也显示它是 iPhone / iPad 可用的代理工具。 

**2）准备配置** 

到你的面板里找到这个节点，选择下面两种方式之一： 

- **显示二维码** 

- **复制链接** 

你上传的文档里写得很明确：面板可以点 “二维码” 给手机扫码，也可以点 “查看 / 复制链接” 直接拿到配置信息。 

**3）导入到 Shadowrocket** 

打开 Shadowrocket 后，做下面其中一种： 

- **如果你拿到的是二维码**：在 Shadowrocket 里选择**扫码导入**，对准面板上的二维码扫进去。 

- **如果你拿到的是链接**：在 Shadowrocket 里选择**从链接 / URL 导入**，把刚才复制的节点链接或订阅链接贴进去保存。 

你上传的文档说明了 “二维码或链接都可以给手机直接添加”，而 Shadowrocket 的 App Store 页面也写了支持从 URL 导入。 

**4）启用连接** 

导入完成后，回到 Shadowrocket 的主界面： 

1. 选中刚导入的节点或订阅里的节点。 

1. 打开连接开关。 

1. 第一次启用时，按 iPhone 的系统提示完成授权。 

**5）测试是否成功** 

打开 Safari 或 Chrome，访问你文档里给的测试站点： 

[https://ip111.cn](https://ip111.cn/) 

如果显示的出口 IP 已经变成你节点对应的 IP，说明客户端已经连通。这个测试站点就是你上传文档里给出的验证方法。 

 

## **二、Linux 端操作指南（推荐用 v2rayA）** 

你上传的文档**没有展开 Linux 客户端安装**，所以这部分我补了一版当前可落地的官方做法。v2rayA 的官方文档把它定位成一个**面向 Linux 的 V2Ray 客户端**，而且它是 **Web GUI**，装好后可以直接用浏览器操作。 

**方案 A：Ubuntu / Debian（最省事）** 

**1）安装 v2rayA** 

官方文档给出的 Debian / Ubuntu 安装方式是添加 v2rayA 软件源，然后安装 v2raya 和 v2ray。 

wget -qO - https://apt.v2raya.org/key/public-key.asc | sudo tee /etc/apt/keyrings/v2raya.asc 
echo "deb [signed-by=/etc/apt/keyrings/v2raya.asc] https://apt.v2raya.org/ v2raya main" | sudo tee /etc/apt/sources.list.d/v2raya.list 
sudo apt update 
sudo apt install v2raya v2ray 

如果你更想用 Xray，官方文档也写了可以把 v2ray 换成 xray。 

**2）启动并设为开机自启** 

安装后执行下面两条命令。官方说明从 1.5 版本开始，v2rayA **不会默认自动启动**，所以这一步需要手动做。 

sudo systemctl start v2raya.service 
sudo systemctl enable v2raya.service 

**3）打开管理界面** 

安装完成后，在 Linux 本机浏览器打开： 

[http://localhost:2017](http://localhost:2017/) 

官方快速开始文档把 2017 作为默认 UI 入口；参数文档也写了默认监听地址是 0.0.0.0:2017。 

**4）首次进入先创建管理员账号** 

第一次打开页面时，先创建一个管理员账号和密码。官方快速开始文档明确写了首次进入需要创建管理员账户。 

**5）导入节点** 

进入 v2rayA 后，选择 “导入” 节点。官方文档写明它支持： 

- 节点链接 

- 订阅链接 

- 扫描二维码 

- 批量导入 

也就是说，你可以直接把面板复制出来的链接贴进去，或者扫面板二维码。 

**6）连接节点并启动服务** 

导入成功后： 

1. 在节点列表里选中你要用的节点。 

1. 点击连接。 

1. 再启动服务。 

官方快速开始文档的顺序就是 “导入节点 → 连接节点 → 启动服务”。 

**7）让应用走代理** 

v2rayA 官方文档给了三种使用方式： 

- **透明代理**：推荐，基本所有程序都能走代理。 

- **系统代理**：适合会主动读取系统代理的程序。 

- **浏览器插件方式**：只给浏览器用。 

另外，官方还写了默认会开放这些本地端口：20170（SOCKS5）、20171（HTTP）、20172（带分流规则的 HTTP）。 

**8）验证是否成功** 

和 iPhone 一样，打开浏览器访问： 

[https://ip111.cn](https://ip111.cn/) 

看出口 IP 是否已经变化。这一步和你上传文档里的验证方式一致。 

 

## **三、Windows 客户端具体操作指南** 

**1）先准备好节点信息** 

先到你的面板里，把节点信息准备出来。按你文档里的做法，有两种最方便的方式： 

- 点 **“二维码”**，生成二维码 

- 点 **“查看” → “复制链接”**，拿到分享链接或订阅链接 

文档原文就是这样给客户端导入配置的。 

**2）下载 Windows 客户端** 

去 **v2rayN 官方 GitHub Releases** 下载 Windows 版本。现在官方 Wiki 对 Windows x64 给了两个常用包： 

- v2rayN-windows-64.zip 

- v2rayN-windows-64-desktop.zip 

一般直接下 v2rayN-windows-64.zip 就行；如果你更想用 Avalonia 桌面界面，可以下 -desktop.zip。官方也写了支持系统是 **Windows 10+**。 

**3）解压并启动** 

把下载好的 zip 解压到一个文件夹里，然后直接运行 v2rayN.exe。 
因为官方说明 zip 包是便携版，所以不需要安装器，解压即可用。 

**4）把节点导入 v2rayN** 

这里分两种情况。 

**情况 A：你拿到的是 “分享链接”** 
先复制这条链接，然后回到 v2rayN 主界面，在**非输入框区域**直接按 **Ctrl + V**。官方 Wiki 写明了这个功能：v2rayN 会读取系统剪贴板内容；如果能识别为分享链接，就按分享链接逻辑解析导入。 

**情况 B：你拿到的是 “订阅链接”** 
也是先复制链接，然后在 v2rayN 主界面按 **Ctrl + V**。官方 Wiki 说明：如果剪贴板内容是 **https 开头**，v2rayN 会按 “ **新增订阅**” 逻辑处理。添加完后，你再在软件里执行一次 **更新订阅**，把节点拉下来。 

你原文里虽然是截图写 “添加节点信息”，但如果你已经从面板拿到了链接， **Ctrl + V 导入**会更省事。 

**5）选中节点** 

导入成功后，在 v2rayN 的节点列表里选中你要用的那个节点。 
如果你导入的是订阅，先更新订阅，再从列表里选一个节点作为当前节点。官方 Wiki 也说明了 v2rayN 有完整的订阅解析和更新流程。 

**6）按你的文档切到 PAC 模式** 

你的文档示例是 **PAC 模式**，所以直接照这个做就行。 

v2rayN 官方 Wiki 对 **PAC 模式** 的定义是：启动或重启服务时，强制让 Windows 使用 PAC 脚本；命中 DIRECT 的地址直连，命中 PROXY 的流量交给核心转发。 

所以这一步你就做两件事： 

1. 在 v2rayN 里把**系统代理模式**切到 **PAC 模式** 

1. 确认 v2rayN 处于运行状态 

这样就和你文档里的 Windows 示例保持一致。 

**7）让 Windows 浏览器走这个代理** 

你文档后面专门写了 “浏览器访问（以 Chrome 为例）”，核心就是：让 **Windows 使用 PAC 模式**。 

实际理解成一句话就够了： 
**v2rayN 负责提供本地代理 / PAC 脚本，Windows / 浏览器按 PAC 规则决定哪些流量走代理。** 这和官方 Wiki 对 “系统代理” 的说明一致。 

**8）验证是否成功** 

最后打开浏览器访问你文档里的测试站点： 

[https://ip111.cn](https://ip111.cn/) 

如果显示的出口 IP 已经变成你的节点出口 IP，就说明 Windows 客户端已经正常工作了。这个验证方法就是你文档原文里的最后一步。 

 

 